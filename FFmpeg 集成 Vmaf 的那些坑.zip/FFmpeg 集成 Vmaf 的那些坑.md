# FFmpeg 集成 Vmaf 的那些坑

@(开发)[工具使用]

> Vmaf 提供了libvmaf.a 的静态库，在ffmpeg上，通过增加编译选项可以让vmaf成为ffmpeg的一个filter. 由于ffmpeg的windows编译支持不太好，所以本文重点放在linux系统上工具环境的搭建上。

## Vmaf的安装
从vmaf 官网下载源码（https://github.com/Netflix/vmaf），放到服务器目录下
执行
```bash
make
make install
```
如果结果如下，则说明安装成功

![Alt text](./1548055559660.png)

这里重点关注 libvmaf.a 文件与 libvmaf.pc文件

## FFmpeg安装
从ffmpeg官网（https://github.com/FFmpeg/FFmpeg）下载源码，放到服务器目录下
###添加vmaf配置项，执行
```bash
./configure --enable-version3 --enable-libvmaf
```
1. 可能出现错误
![Alt text](./1548056209143.png)

这说明汇编加速没有安装，解决步骤如下
下载yasm库 http://www.tortall.net/projects/yasm/releases/yasm-1.3.0.tar.gz
按如下步骤安装部署
```bash
tar zxvf yasm-1.3.0.tar.gz
cd yasm-1.3.0
./configure
make
make install
```
2. 可能出现错误
![Alt text](./1548057892379.png)
这说明pkg-config没有找到相应的文件 .pc
执行命令

```bash
pkg-config --variable pc_path pkg-config
```
找到pkg-config的目录，将.pc文件拷贝到该目录下
![Alt text](./1548067958556.png)
```bash
cp /usr/local/lib/pkgconfig/libvmaf.pc /usr/share/pkgconfig/libvmaf.pc
```
没有错误后继续
### 编译
```bash
make
make install
```
## 验证
```bash
ffmpeg -i blur.mp4 -i original.mp4 -lavfi libvmaf  -f null -
```