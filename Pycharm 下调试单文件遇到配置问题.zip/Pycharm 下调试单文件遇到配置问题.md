# Pycharm 下调试单文件遇到配置问题

@(开发)[python]

调试单文件时有时会遇到 “DJANGO_SETTING_MODULE” 的问题
![Alt text](./1547716203024.png)

## 解决方案
将配置添加到pycharm的python配置中
![Alt text](./1547716279487.png)
![Alt text](./1547716301045.png)
![Alt text](./1547716311653.png)
