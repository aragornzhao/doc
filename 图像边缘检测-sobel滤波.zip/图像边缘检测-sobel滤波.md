# 图像边缘检测-sobel滤波

@(信号处理)[图像]

## 原理
索贝尔算子（Sobel operator）主要用作边缘检测，在技术上，它是一离散性差分算子，用来运算图像亮度函数的灰度之近似值。在图像的任何一点使用此算子，将会产生对应的灰度矢量或是其法矢量
Sobel卷积因子为：
![Alt text](./1550552336597.png)
该算子包含两组3x3的矩阵，分别为横向及纵向，将之与图像作平面卷积，即可分别得出横向及纵向的亮度差分近似值。如果以A代表原始图像，Gx及Gy分别代表经横向及纵向边缘检测的图像灰度值，其公式如下：

 ![Alt text](./1550552422460.png)


具体计算如下：

Gx = (-1)*f(x-1, y-1) + 0*f(x,y-1) + 1*f(x+1,y-1)+(-2)*f(x-1,y) + 0*f(x,y)+2*f(x+1,y)+(-1)*f(x-1,y+1) + 0*f(x,y+1) + 1*f(x+1,y+1)= [f(x+1,y-1)+2*f(x+1,y)+f(x+1,y+1)]-[f(x-1,y-1)+2*f(x-1,y)+f(x-1,y+1)]
 
Gy =1* f(x-1, y-1) + 2*f(x,y-1)+ 1*f(x+1,y-1) +0*f(x-1,y) 0*f(x,y) + 0*f(x+1,y)+(-1)*f(x-1,y+1) + (-2)*f(x,y+1) + (-1)*f(x+1, y+1)= [f(x-1,y-1) + 2f(x,y-1) + f(x+1,y-1)]-[f(x-1, y+1) + 2*f(x,y+1)+f(x+1,y+1)]


其中f(a,b), 表示图像(a,b)点的灰度值；


图像的每一个像素的横向及纵向灰度值通过以下公式结合，来计算该点灰度的大小：
![Alt text](./1550552460395.png)


通常，为了提高效率 使用不开平方的近似值：
![Alt text](./1550552471469.png)

## 代码实现
示例处理图片
![Alt text](./sobel.jpg)

```matlab
data = imread('sobel.jpg');
gray_image = rgb2gray(data);
gray_image_ex=zeros(size(gray_image)+2);
gray_image_ex(2:size(gray_image,1)+1, 2:size(gray_image,2)+1) = gray_image;
grad_self = zeros(size(gray_image));

for i=2:size(gray_image_ex,1)-1
    for j=2:size(gray_image_ex,2)-1
        Gx=gray_image_ex(i+1,j-1) + 2*gray_image_ex(i+1,j)+ gray_image_ex(i+1, j+1)- (gray_image_ex(i-1,j-1) + 2*gray_image_ex(i-1,j)+ gray_image_ex(i-1, j+1));
        Gy=gray_image_ex(i-1,j-1) + 2*gray_image_ex(i,j-1)+ gray_image_ex(i+1, j-1)- (gray_image_ex(i-1,j+1) + 2*gray_image_ex(i,j+1)+ gray_image_ex(i+1, j+1));
        % x 分量滤波
        % data(i-1,j-1) = abs(Gx);
        % y 分量滤波
        % data(i-1,j-1) = abs(Gy);
        % x, y 分量都有,
        grad_self(i-1,j-1) = sqrt(Gx^2 + Gy^2);
        
    end
end


subplot(3,2,1); 
imshow(gray_image);  
title('原图'); 


hx=[-1 -2 -1;0 0 0 ;1 2 1];%生产sobel垂直梯度模板
hy=hx';                             %生产sobel水平梯度模板

gradx=filter2(hx,I,'same');
gradx=abs(gradx); %计算图像的sobel垂直梯度
subplot(3,2,3);
imshow(gradx,[]);
title('图像的sobel垂直梯度');


grady=filter2(hy,I,'same');
grady=abs(grady); %计算图像的sobel水平梯度
subplot(3,2,4);
imshow(grady,[]);
title('图像的sobel水平梯度');

grad=gradx+grady;  %得到图像的sobel梯度
subplot(3,2,5);
imshow(grad,[]);
title('图像的sobel梯度');

subplot(3,2,6)
imshow(grad_self, []) %实现sobel滤波方法
title('图像的sobel梯度-self');
```