#! /bin/bash

while [[ 1 ]]; do

    CNT=$( ps -wwef | grep cron | grep -v grep | wc -l )

    if (( CNT == 0 )); then
        /etc/init.d/cron start
    fi

    sleep 1m

done
