# --------- val -----------
## 检查的时间间隔
INTERVAL=5s
## 要检查的程序
APP=cron
## 日志的位置
LOG=$( dirname $0 )/log
