#! /bin/bash

## 脚本功能：监控cron
## by samli 2009-11-16

# -------------------- val --------------------
## 避免命令找不到
PATH=/sbin:/usr/sbin:/usr/local/sbin:/usr/local/bin:/usr/bin:/bin
## 检查的时间间隔
INTERVAL=3s
## 要检查的程序
APP=cron
## 日志的位置
LOG=$( dirname $0 )/log

# -------------------- main --------------------
while true; do
    ##　判断进程是否存在
    if killall -0 $APP &> /dev/null; then
        {   date
            echo "$IP $APP OK"
        } >> "$LOG"
    ##　如果进程不存在, 则告警、拉起进程
    else
        /usr/local/agenttools/agent/agentRepStr \
        12345 "$APP restarted"
        {    date
            /etc/init.d/cron start
        } >> $LOG 2>&1
    fi

    sleep $INTERVAL
done
# -------------------- end --------------------
