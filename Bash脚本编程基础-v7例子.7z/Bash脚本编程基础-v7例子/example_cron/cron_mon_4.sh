#! /bin/bash

## 脚本功能：监控进程cron
## by samli 2009-11-16

## 避免命令找不到
PATH=/sbin:/usr/sbin:/usr/local/sbin:/usr/local/bin:/usr/bin:/bin

## 进入监控脚本所在的目录
cd "$( dirname $0 )" || exit 1
. ./config.sh 
. ./fun.sh 

# --------------------
TIME=$( date +%F_%T )

while true; do
    ## 如果进程OK
    if app_ok "$APP"; then
        write_log "[$TIME] OK, $APP running" 
    ## 如果进程不OK
    else
        ## 告警，记日志，拉起进程
        send_msg "crond restarted"
        write_log "[$TIME] ERROR, $APP dead"
        restart_cron
    fi

    ## 让CPU歇一下
    sleep $INTERVAL
done
