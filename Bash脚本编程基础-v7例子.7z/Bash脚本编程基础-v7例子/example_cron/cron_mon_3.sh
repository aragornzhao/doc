#! /bin/bash

## 脚本功能:监控进程cron
## by samli 2009-11-16

# --------- val -----------
## 避免命令找不到
PATH=/sbin:/usr/sbin:/usr/local/sbin:/usr/local/bin:/usr/bin:/bin
## 检查的时间间隔
INTERVAL=5s
## 要检查的程序
APP=cron
## 日志的位置
LOG=$( dirname $0 )/log

# --------- func -----------
## 发送告警
send_msg()
{
    /usr/local/agenttools/agent/agentRepStr 12345 "$@"
}

## 检查进程
app_ok()
{
    killall -0 "$1" &> /dev/null;
}

## 记录日志
write_log()
{
    echo "$@" >> "$LOG"
}

## 重启cron
restart_cron()
{
    /etc/init.d/cron restart &> /dev/null
}

# --------- main -----------
IP=$( get_localip )

while true; do
    TIME=$( date +%F_%T )

    ## 如果进程OK
    if app_ok "$APP"; then
        write_log "[$TIME $IP] OK $APP running" 
    ## 如果进程不OK
    else
        ## 告警，记日志，拉起进程
        send_msg "$IP crond restarted"
        write_log "[$TIME $IP] ERROR $APP restarted"
        restart_cron
    fi

    ## 让CPU歇一下
    sleep $INTERVAL
done
