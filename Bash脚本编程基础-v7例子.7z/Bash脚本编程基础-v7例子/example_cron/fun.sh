# --------- func -----------
## 发送告警
send_msg()
{
    /usr/local/agenttools/agent/agentRepStr 12345 "$@"
}

## 检查进程
app_ok()
{
    killall -0 "$1" &> /dev/null;
}

## 重启cron
restart_cron()
{
    /etc/init.d/cron restart &> /dev/null
}

## 记录日志
write_log()
{
    if [[ -z $LOG ]]; then
        LOG=/tmp/$0.log
    fi
    echo "$@" >> "$LOG"
}
