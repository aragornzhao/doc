#! /bin/bash

var="hello shanghai"
echo var=$var
