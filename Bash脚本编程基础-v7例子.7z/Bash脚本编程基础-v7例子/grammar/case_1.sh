#! /bin/bash

ls /dev/sda* |
while read dev; do
    case $dev in
       */[hs]d[a-z]?)
            echo "? OK: $dev"
            ;;
    esac
done
