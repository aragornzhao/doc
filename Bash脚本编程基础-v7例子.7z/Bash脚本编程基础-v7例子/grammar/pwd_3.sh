#! /bin/bash

get_workdir()
{
    local dir=$( dirname $0 )
    pwd=$( cd $dir && pwd )

    echo $pwd
}

get_workdir
