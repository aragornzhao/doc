#! /bin/bash

file=$0     # 脚本本身
cnt=0      # 行数

cat $file | while read; do
    (( cnt ++ ))             # 每行一行，cnt加一
    echo -e "$cnt:\t$REPLY"
done    

echo "total:[$cnt]"     # 打印最后结果
