#!/bin/bash
pwd
