#! /bin/bash

STR="H e l l o - T e n c e n t!"

## 更高精度的sleep函数
my_sleep()
{   
    local sec=$1
    perl -e "select( undef, undef, undef, $sec )"
}

## 从这里开始执行
for s in $STR; do
    echo -n $s
    if [[ "$s" == "-" ]]; then
        my_sleep 1
    else
        my_sleep 0.1
    fi
done

echo; echo
