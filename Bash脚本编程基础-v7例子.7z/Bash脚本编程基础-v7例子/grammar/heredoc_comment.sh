#! /bin/bash

: <<EOF
echo line no.1
echo line no.2
echo line no.3
echo line no.4
EOF

echo we are here
