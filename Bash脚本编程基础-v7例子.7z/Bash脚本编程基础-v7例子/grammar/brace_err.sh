#! /bin/bash

i=$1
j=$2

eval echo {$i..$j}
