#! /bin/bash

cat <<END | tee /dev/null
line no.1
line no.2
line no.3
line no.4
END
