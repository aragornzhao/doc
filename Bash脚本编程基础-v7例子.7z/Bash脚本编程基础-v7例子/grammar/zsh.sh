#! /bin/bash

cd /tmp || exit 1
date > a > b
