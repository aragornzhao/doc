#! /bin/bash

readlink /proc/$$/fd/255
