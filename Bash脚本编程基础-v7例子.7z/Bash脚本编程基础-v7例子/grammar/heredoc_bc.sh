#! /bin/bash

echo "pipe ..."
echo "scale = 3; 10 / 3" | bc

echo

echo "here doc ..."
bc <<EOF
scale =  3
10 / 3
EOF
