 #! /bin/bash

case $0 in
    */vim.sh|vim.sh)
        echo "running in vim mode ..."
        ;;
    */vi.sh|vi.sh)
        echo "running in vi  mode ..."
        ;;
    *)
        echo "running in unknown mode ..."
        ;;
esac
