#! /bin/bash

grep -q samli /etc/passwd     &&
    ( echo "found"; false )   ||
    echo "not found"
