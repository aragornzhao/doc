#! /bin/bash

readlink /proc/$$/fd/255
dirname $( readlink /proc/$$/fd/255 )
