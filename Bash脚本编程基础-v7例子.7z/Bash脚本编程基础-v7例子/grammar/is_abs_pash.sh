#! /bin/bash

path=$1

case $path in 
    /*)
        echo "[$path] is abs path"
        ;;
    *)
        echo "[$path] is not abs path"
        ;;
esac
    
