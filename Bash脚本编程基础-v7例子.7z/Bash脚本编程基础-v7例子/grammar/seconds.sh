#! /bin/bash

while :; do
    echo "[$SECONDS]"
    sleep 1
done
