#! /bin/bash

ls -log /proc/$$/fd/{0,1,2,255}
