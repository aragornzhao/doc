

echo {00..10}
