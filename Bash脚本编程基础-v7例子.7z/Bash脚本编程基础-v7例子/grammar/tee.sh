 #! /bin/bash

str="abc"

if [[ $str == "abc" ]]; then
    result=YES
    echo $result
fi
# fi | tee log


echo "[result:$result]"
