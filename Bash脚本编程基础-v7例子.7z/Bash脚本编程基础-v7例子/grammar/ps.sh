#!/bin/bash



ps -o pid,ppid,cmd
