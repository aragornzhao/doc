#! /bin/bash

file=$0
cnt=0

while read; do
    (( cnt ++ ))
    echo -e "$cnt:\t$REPLY"
done < $file   

echo "total:[$cnt]"
