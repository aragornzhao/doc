#! /bin/bash

pwd
