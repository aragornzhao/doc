#! /bin/bash

echo 1 > /tmp/test/1
echo 1 > /tmp/test/2
echo 1 > /tmp/test/3
echo 1 > /tmp/test/4
echo 1 > /tmp/test/5
echo 1 > /tmp/test/6

