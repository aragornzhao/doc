#! /bin/bash

a=~huan

if [[ $a == "~huan" ]]; then
    echo "user not found"
else
    echo "user found, home:[$a]"
fi
