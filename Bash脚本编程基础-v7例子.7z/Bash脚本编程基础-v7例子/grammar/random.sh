#! /bin/bash

while :; do
    echo "[$RANDOM]"
    sleep 1
done
